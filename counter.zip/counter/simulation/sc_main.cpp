#include "sc_counter_TB.h"

int sc_main(int argc, char** argv)
{
    //Verilated::commandArgs(argc, argv);

    sc_counter_TB u_sc_counter_TB("u_sc_counter_TB");

    //sc_start(10, SC_MS);
    sc_start();

    return 0;
}
