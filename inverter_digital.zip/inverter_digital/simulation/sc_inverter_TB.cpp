//
// Filename: sc_pong_SbS_TB.cpp
//

#include "sc_inverter_TB.h"

void sc_inverter_TB::Test_Gen()
{
    usr_input.write(true);

    wait(sys_clk.posedge_event());
    wait(sys_clk.posedge_event());
    wait(sys_clk.posedge_event());

    usr_input.write(false);

    while(true)
    {
        wait(sys_clk.posedge_event());
        wait(sys_clk.negedge_event());

        wait(sys_clk.posedge_event());
        wait(sys_clk.negedge_event());

        wait(sys_clk.posedge_event());
        wait(sys_clk.negedge_event());

        wait(sys_clk.posedge_event());
        wait(sys_clk.negedge_event());

        wait(sys_clk.posedge_event());
        wait(sys_clk.negedge_event());

        wait(sys_clk.posedge_event());
        wait(sys_clk.negedge_event());
        usr_input.write(true);

        wait(sys_clk.posedge_event());
        wait(sys_clk.negedge_event());

        sc_stop();
    }
}
