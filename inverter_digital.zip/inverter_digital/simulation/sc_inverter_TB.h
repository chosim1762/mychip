//
// Filename: sc_pong_SbS_TB.h
//

#ifndef _SC_INVERTER_TB_H_
#define _SC_INVERTER_TB_H_

#include <systemc.h>
#ifdef VCD_TRACE_DUT_VERILOG
#include <verilated_vcd_sc.h>
#endif

#include "Vinverter.h"

SC_MODULE(sc_inverter_TB)
{
    sc_clock        sys_clk;
    sc_signal<bool> usr_input;
    sc_signal<sc_uint<2> > led;

    Vinverter*  u_inverter;

    #ifdef  VCD_TRACE_TEST_TB
    sc_trace_file* fp;  // VCD file
#endif

#ifdef VCD_TRACE_DUT_VERILOG
    VerilatedVcdSc*     tfp;    // Verilator VCD
#endif

    void Test_Gen(void);

    SC_CTOR(sc_inverter_TB):
            sys_clk("sys_clk", 100, SC_NS, 0.5, 0.0, SC_NS, false)
    {
        SC_THREAD(Test_Gen);
        sensitive << sys_clk;

        // Instantiate DUT ----------
        u_inverter = new Vinverter("u_inverter");
        u_inverter->sys_clk(sys_clk);
        u_inverter->usr_input(usr_input);
        u_inverter->led(led);

#ifdef VCD_TRACE_TEST_TB
        // VCD Trace
        fp = sc_create_vcd_trace_file("sc_inverter_TB");
        fp->set_time_unit(100, SC_PS);
        sc_trace(fp, sys_clk,   "sys_clk");
        sc_trace(fp, usr_input, "usr_input");
        sc_trace(fp, led, "led");
#endif

#ifdef VCD_TRACE_DUT_VERILOG
        // Trace Verilated Verilog internals
        Verilated::traceEverOn(true);

        tfp = new VerilatedVcdSc;
        sc_start(SC_ZERO_TIME);
        u_inverter->trace(tfp, 99);  // Trace levels of hierarchy
        tfp->open("Vinverter.vcd");
#endif
    }
};
#endif
