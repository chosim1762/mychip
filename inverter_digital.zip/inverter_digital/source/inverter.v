module inverter (
    input sys_clk,          // clk input
    input usr_input,        // reset input
    output reg [1:0] led    // 110 R, 101 G, 001 B
);

always @(posedge sys_clk) begin
    if (usr_input)
        led <= 2'b01;
    else
        led <= 2'b10;
end

endmodule
